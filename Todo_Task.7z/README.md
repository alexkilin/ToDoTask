How to run:
- 

- You should execute `mvn clean package -DskipTests`. After that in your root project directory you will find `target` dir and `TodoTask-0.0.1-SNAPSHOT.jar`
- After first step you can run `docker-compose up -d` from root project directory path.
- Command from previous step will create a containers named app and db. App is - TodoTask app, db - is postgresql database.
- Finally, you can check how it works!


API:  
- POST http://localhost:8080/api/v1/signup
Request for registration user  
Body example `{
  "email": "test@test.com",
  "password": "1234"
  }`
- POST http://localhost:8080/api/v1/signin
Request for login user  
Body example `{
  "email": "test@test.com",
  "password": "1234"
  }`  
After success login you will get a token, token you should use in headers. 
You should use "Authorization" header and value like - "Bearer `token`"
- PUT http://localhost:8080/api/v1/changePassword
Request for change user password.  
You should be authorized to make this request.  
Body example `{
  "password": "4321"
  }`
- GET http://localhost:8080/api/v1/todos?status={status}
Request to get all todo items for current user.  
You should be authorized to make this request.  
Status variants - [NotStarted, OnGoing, Completed], request parameter "status" is not required  
Response example 
````
  [
  {
  "id": 1,
  "name": "Test2",
  "description": "test test2",
  "createdTimestamp": "2022-12-11T09:53:20.727273Z",
  "updatedTimestamp": "2022-12-11T09:53:20.727280Z",
  "status": "NotStarted"
  }
  ]
````
- POST http://localhost:8080/api/v1/todos
Request to create new todo item.  
You should be authorized to make this request.  
Body example `{
  "name": "Test",
  "description": "test test"
  }`
- PUT http://localhost:8080/api/v1/todos/{id}
Request to update todo item.  
You should be authorized to make this request. You cannot delete not yours items.   
Path parameter `id` is id of todo item. Body example `{
  "name": "updatedTest",
  "description": "",
  "status": "Completed"
  }`
- DELETE http://localhost:8080/api/v1/todos/{id}
Request to delete todo item.  
You should be authorized to make this request. You cannot delete not yours items.   
Path parameter `id` is id of todo item. 