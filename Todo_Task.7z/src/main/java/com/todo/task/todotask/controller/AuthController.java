package com.todo.task.todotask.controller;

import com.todo.task.todotask.dto.ChangePasswordDto;
import com.todo.task.todotask.dto.LoginRequestDto;
import com.todo.task.todotask.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class AuthController {

    private final AuthService authService;

    @Autowired
    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequestDto loginRequest) {
        return ResponseEntity.ok(authService.login(loginRequest));
    }

    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@RequestBody LoginRequestDto signUpRequest) {
        return ResponseEntity.ok(authService.registerUser(signUpRequest));
    }

    @PutMapping("/changePassword")
    public ResponseEntity<?> changeUserPassword(@RequestBody ChangePasswordDto changePasswordDto) {
        return ResponseEntity.ok(authService.changePassword(changePasswordDto.getPassword()));
    }
}
