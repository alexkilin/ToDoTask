package com.todo.task.todotask.service;

import com.todo.task.todotask.dto.CreateTodoRequestDto;
import com.todo.task.todotask.dto.MessageResponseDto;
import com.todo.task.todotask.dto.TodoDto;
import com.todo.task.todotask.dto.UpdateTodoRequestDto;
import com.todo.task.todotask.entity.Status;
import com.todo.task.todotask.entity.Todo;
import com.todo.task.todotask.entity.User;
import com.todo.task.todotask.repository.TodoRepository;
import com.todo.task.todotask.repository.UserRepository;
import com.todo.task.todotask.security.UserDetailsImpl;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TodoService {

    private final TodoRepository repository;
    private final UserRepository userRepository;

    public TodoService(TodoRepository repository, UserRepository userRepository) {
        this.repository = repository;
        this.userRepository = userRepository;
    }

    public List<TodoDto> getAllTodo(Status status) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (status == null) {
            return repository.findAllByUserId(userDetails.id()).stream().map(e -> new TodoDto(
                    e.getId(),
                    e.getName(),
                    e.getDescription(),
                    e.getCreatedTimestamp(),
                    e.getUpdatedTimestamp(),
                    e.getStatus()
            )).collect(Collectors.toList());
        }
        return repository.findAllByUserIdAndStatus(userDetails.id(), status).stream().map(e -> new TodoDto(
                e.getId(),
                e.getName(),
                e.getDescription(),
                e.getCreatedTimestamp(),
                e.getUpdatedTimestamp(),
                e.getStatus()
        )).collect(Collectors.toList());
    }

    public MessageResponseDto createTodo(CreateTodoRequestDto todoDto) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        Todo todo = new Todo();
        todo.setName(todoDto.name());
        todo.setDescription(todoDto.description() == null ? "" : todoDto.description());
        todo.setUser(getUserByEmail(userDetails.email()));
        todo.setCreatedTimestamp(Instant.now());
        todo.setUpdatedTimestamp(Instant.now());
        todo.setStatus(Status.NotStarted);

        repository.save(todo);
        return new MessageResponseDto("Todo created!");
    }

    public MessageResponseDto updateTodo(UpdateTodoRequestDto requestDto, Long id) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        User user = getUserByEmail(userDetails.email());

        Todo todo = repository.findById(id).orElseThrow();

        if (checkIsTodoAvailableForUser(todo, user)) {
            todo.setName(requestDto.name());
            todo.setDescription(requestDto.description());
            todo.setUpdatedTimestamp(Instant.now());
            todo.setStatus(requestDto.status());
            repository.save(todo);
            return new MessageResponseDto("Todo edited!");
        } else {
            return new MessageResponseDto("This todo is not yours, you cannot edit it!");
        }
    }

    public MessageResponseDto deleteTodo(Long id) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        User user = getUserByEmail(userDetails.email());

        Todo todo = repository.findById(id).orElseThrow();

        if (checkIsTodoAvailableForUser(todo, user)) {
            repository.delete(todo);
            return new MessageResponseDto("Todo deleted!");
        } else {
            return new MessageResponseDto("This todo is not yours, you cannot delete it!");
        }
    }

    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email).orElseThrow();
    }

    private boolean checkIsTodoAvailableForUser(Todo todo, User user) {
        return Objects.equals(todo.getUser().getId(), user.getId());
    }
}
