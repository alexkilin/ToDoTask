package com.todo.task.todotask.controller;

import com.todo.task.todotask.dto.CreateTodoRequestDto;
import com.todo.task.todotask.dto.TodoDto;
import com.todo.task.todotask.dto.UpdateTodoRequestDto;
import com.todo.task.todotask.entity.Status;
import com.todo.task.todotask.security.UserDetailsImpl;
import com.todo.task.todotask.service.TodoService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class TodoController {

    private final TodoService todoService;

    public TodoController(TodoService todoService) {
        this.todoService = todoService;
    }

    @GetMapping("/todos")
    public ResponseEntity<?> getAllTodos(@RequestParam(required = false) Status status) {
        return ResponseEntity.ok(todoService.getAllTodo(status));
    }

    @PostMapping("/todos")
    public ResponseEntity<?> createTodo(@RequestBody CreateTodoRequestDto todoDto) {
        return ResponseEntity.ok(todoService.createTodo(todoDto));
    }

    @PutMapping("/todos/{id}")
    public ResponseEntity<?> updateTodo(@RequestBody UpdateTodoRequestDto requestDto, @PathVariable Long id) {
        return ResponseEntity.ok(todoService.updateTodo(requestDto, id));
    }

    @DeleteMapping("/todos/{id}")
    public ResponseEntity<?> deleteTodo(@PathVariable Long id) {
        return ResponseEntity.ok(todoService.deleteTodo(id));
    }
}
