package com.todo.task.todotask.dto;

import lombok.Data;

@Data
public class ChangePasswordDto {
    private String password;
}
