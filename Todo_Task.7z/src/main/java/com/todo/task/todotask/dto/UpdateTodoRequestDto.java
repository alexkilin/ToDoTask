package com.todo.task.todotask.dto;

import com.todo.task.todotask.entity.Status;

import java.io.Serializable;

public record UpdateTodoRequestDto(String name, String description, Status status) implements Serializable {
}
