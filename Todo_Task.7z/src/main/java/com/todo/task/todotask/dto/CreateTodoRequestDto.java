package com.todo.task.todotask.dto;

import java.io.Serializable;

public record CreateTodoRequestDto(String name, String description) implements Serializable {
}
