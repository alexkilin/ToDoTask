package com.todo.task.todotask.exceptions;

public class PasswordChangeException extends RuntimeException {

    public PasswordChangeException() {
        super("Password Change Error!");
    }
}
