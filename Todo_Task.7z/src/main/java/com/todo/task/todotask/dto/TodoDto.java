package com.todo.task.todotask.dto;

import com.todo.task.todotask.entity.Status;
import com.todo.task.todotask.entity.Todo;
import lombok.Data;

import java.io.Serializable;
import java.sql.Date;
import java.time.Instant;

/**
 * A DTO for the {@link Todo} entity
 */
public record TodoDto(Long id, String name, String description, Instant createdTimestamp, Instant updatedTimestamp,
                      Status status) implements Serializable {
}