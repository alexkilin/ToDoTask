package com.todo.task.todotask.entity;

public enum Status {
    NotStarted, OnGoing, Completed
}
