package com.todo.task.todotask.service;

import com.todo.task.todotask.dto.LoginRequestDto;
import com.todo.task.todotask.dto.MessageResponseDto;
import com.todo.task.todotask.entity.User;
import com.todo.task.todotask.exceptions.PasswordChangeException;
import com.todo.task.todotask.repository.UserRepository;
import com.todo.task.todotask.security.JwtUtils;
import com.todo.task.todotask.security.UserDetailsImpl;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Optional;

@Service
public class AuthService {
    private final UserRepository userRepository;
    private final PasswordEncoder encoder;
    private final JwtUtils jwtUtils;
    private final AuthenticationManager authenticationManager;

    public AuthService(UserRepository userRepository, PasswordEncoder encoder, JwtUtils jwtUtils, AuthenticationManager authenticationManager) {
        this.userRepository = userRepository;
        this.encoder = encoder;
        this.jwtUtils = jwtUtils;
        this.authenticationManager = authenticationManager;
    }

    public MessageResponseDto changePassword(String newPassword) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        Optional<User> user = userRepository.findByEmail(userDetails.email());

        user.map(u -> {
            u.setPassword(encoder.encode(newPassword));
            u.setUpdatedTimestamp(Instant.now());
            userRepository.save(u);
            return u;
        }).orElseThrow(PasswordChangeException::new);
        return new MessageResponseDto("Password changed!");
    }

    public MessageResponseDto registerUser(LoginRequestDto requestDto) {
        if (userRepository.existsByEmail(requestDto.getEmail())) {
            return new MessageResponseDto("Error: Email is already in use!");
        }

        User user = new User(requestDto.getEmail(),
                encoder.encode(requestDto.getPassword()));

        userRepository.save(user);
        return new MessageResponseDto("User registered successfully!");
    }

    public MessageResponseDto login(LoginRequestDto loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtUtils.generateJwtToken(authentication);

        return new MessageResponseDto(jwt);
    }
}
