package com.todo.task.todotask.repository;

import com.todo.task.todotask.entity.Status;
import com.todo.task.todotask.entity.Todo;
import lombok.NonNull;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TodoRepository extends CrudRepository<Todo, Long> {
    @Query("select t from Todo t where t.user.id = :userId")
    List<Todo> findAllByUserId(Long userId);

    @Query("select t from Todo t where t.user.id = :userId and t.status = :status")
    List<Todo> findAllByUserIdAndStatus(Long userId, Status status);

    @Override
    Optional<Todo> findById(@NonNull Long aLong);
}
