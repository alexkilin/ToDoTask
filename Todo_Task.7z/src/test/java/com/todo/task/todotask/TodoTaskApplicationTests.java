package com.todo.task.todotask;

import com.todo.task.todotask.dto.CreateTodoRequestDto;
import com.todo.task.todotask.dto.MessageResponseDto;
import com.todo.task.todotask.dto.TodoDto;
import com.todo.task.todotask.dto.UpdateTodoRequestDto;
import com.todo.task.todotask.entity.Status;
import com.todo.task.todotask.entity.Todo;
import com.todo.task.todotask.entity.User;
import com.todo.task.todotask.repository.TodoRepository;
import com.todo.task.todotask.repository.UserRepository;
import com.todo.task.todotask.security.UserDetailsImpl;
import com.todo.task.todotask.service.TodoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.Instant;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = TodoService.class)
class TodoTaskApplicationTests {

    @MockBean
    TodoRepository todoRepository;

    @MockBean
    UserRepository userRepository;

    @Autowired
    TodoService todoService;

    private final UserDetailsImpl mockUserDetails = new UserDetailsImpl(1L, "test@test.com", Instant.now(), Instant.now(), "1234");
    private final User mockUser = new User("test@test.com", "1234");

    @BeforeEach
    public void setUp() {
        Authentication authentication = Mockito.mock(Authentication.class);
        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.getPrincipal()).thenReturn(mockUserDetails);
        mockUser.setId(1L);
    }

    @Test
    void getAllTodoTest() {

        when(todoRepository.findAllByUserId(1L)).thenReturn(List.of(new Todo(), new Todo()));

        List<TodoDto> allTodo = todoService.getAllTodo(null);

        assertEquals(2, allTodo.size());
    }

    @Test
    void getAllTodoTestWithStatus() {

        when(todoRepository.findAllByUserIdAndStatus(1L, Status.NotStarted)).thenReturn(List.of(new Todo(), new Todo()));

        List<TodoDto> allTodo = todoService.getAllTodo(Status.NotStarted);

        assertEquals(2, allTodo.size());
    }

    @Test
    void getAllTodoTestWithStatusWithIncorrectUserId() {

        when(todoRepository.findAllByUserIdAndStatus(2L, Status.NotStarted)).thenReturn(List.of(new Todo(), new Todo()));

        List<TodoDto> allTodo = todoService.getAllTodo(Status.NotStarted);

        assertEquals(0, allTodo.size());
    }

    @Test
    void createTodoTest() {
        when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(mockUser));
        MessageResponseDto test = todoService.createTodo(new CreateTodoRequestDto("test", "Test description!"));
        assertEquals("Todo created!", test.getData());
    }

    @Test
    void updateTodoTest() {

        Todo mockTodo = new Todo();
        mockTodo.setUser(mockUser);

        when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(mockUser));
        when(todoRepository.findById(10L)).thenReturn(Optional.of(mockTodo));
        MessageResponseDto messageResponseDto = todoService.updateTodo(new UpdateTodoRequestDto("test", "test", Status.OnGoing), 10L);

        assertEquals("Todo edited!", messageResponseDto.getData());
    }

    @Test
    void updateTodoTestNegativeCaseTryingToEditAnotherTodo() {
        Todo mockTodo = new Todo();
        User user = new User();
        user.setId(5L);
        mockTodo.setUser(user);

        when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(mockUser));
        when(todoRepository.findById(10L)).thenReturn(Optional.of(mockTodo));
        MessageResponseDto messageResponseDto = todoService.updateTodo(new UpdateTodoRequestDto("test", "test", Status.OnGoing), 10L);

        assertEquals("This todo is not yours, you cannot edit it!", messageResponseDto.getData());
    }

    @Test
    void updateTodoTestNegativeCaseTryingToEditNotExistingTodo() {
        Todo mockTodo = new Todo();
        mockTodo.setUser(mockUser);

        when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(mockUser));
        when(todoRepository.findById(10L)).thenReturn(Optional.empty());
        assertThrows(NoSuchElementException.class, () -> todoService.updateTodo(new UpdateTodoRequestDto("test", "test", Status.OnGoing), 10L));
    }

    @Test
    void deleteTest() {
        Todo mockTodo = new Todo();
        mockTodo.setUser(mockUser);

        when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(mockUser));
        when(todoRepository.findById(10L)).thenReturn(Optional.of(mockTodo));
        MessageResponseDto messageResponseDto = todoService.deleteTodo(10L);

        assertEquals("Todo deleted!", messageResponseDto.getData());
    }

    @Test
    void deleteTodoTestNegativeCaseTryingToDeleteAnotherTodo() {
        Todo mockTodo = new Todo();
        User user = new User();
        user.setId(5L);
        mockTodo.setUser(user);

        when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(mockUser));
        when(todoRepository.findById(10L)).thenReturn(Optional.of(mockTodo));
        MessageResponseDto messageResponseDto = todoService.deleteTodo(10L);

        assertEquals("This todo is not yours, you cannot delete it!", messageResponseDto.getData());
    }

    @Test
    void deleteTodoTestNegativeCaseTryingToDeleteNotExistingTodo() {
        Todo mockTodo = new Todo();
        mockTodo.setUser(mockUser);

        when(userRepository.findByEmail("test@test.com")).thenReturn(Optional.of(mockUser));
        when(todoRepository.findById(10L)).thenReturn(Optional.empty());
        assertThrows(NoSuchElementException.class, () -> todoService.deleteTodo(10L));
    }
}
